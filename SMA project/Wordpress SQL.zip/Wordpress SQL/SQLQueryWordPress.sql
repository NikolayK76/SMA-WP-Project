﻿CREATE DATABASE WordPressDB;
USE WordPressDB;

CREATE TABLE Users (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(100) NOT NULL,
    Email NVARCHAR(150) NOT NULL,
    Password NVARCHAR(255) NOT NULL,
    Role NVARCHAR(50),
    RegistrationDate DATETIME
);

CREATE TABLE Posts (
    PostID INT PRIMARY KEY IDENTITY(1,1),
    Title NVARCHAR(200) NOT NULL,
    Content NVARCHAR(MAX) NOT NULL,
    PublishDate DATETIME,
    AuthorID INT,
    Status NVARCHAR(50),
    CommentCount INT DEFAULT 0,
    FOREIGN KEY (AuthorID) REFERENCES Users(UserID)
);

CREATE TABLE Comments (
    CommentID INT PRIMARY KEY IDENTITY(1,1),
    Content NVARCHAR(MAX) NOT NULL,
    CommentDate DATETIME,
    PostID INT,
    UserID INT,
    FOREIGN KEY (PostID) REFERENCES Posts(PostID),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE Categories (
    CategoryID INT PRIMARY KEY IDENTITY(1,1),
    CategoryName NVARCHAR(100) NOT NULL,
    Description NVARCHAR(255)
);

CREATE TABLE Tags (
    TagID INT PRIMARY KEY IDENTITY(1,1),
    TagName NVARCHAR(100) NOT NULL
);

CREATE TABLE Media (
    MediaID INT PRIMARY KEY IDENTITY(1,1),
    FileName NVARCHAR(255) NOT NULL,
    FileType NVARCHAR(50),
    UploadDate DATETIME,
    UploadedBy INT,
    FOREIGN KEY (UploadedBy) REFERENCES Users(UserID)
);

CREATE TABLE PostCategories (
    PostID INT,
    CategoryID INT,
    PRIMARY KEY (PostID, CategoryID),
    FOREIGN KEY (PostID) REFERENCES Posts(PostID),
    FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID)
);

CREATE TABLE PostTags (
    PostID INT,
    TagID INT,
    PRIMARY KEY (PostID, TagID),
    FOREIGN KEY (PostID) REFERENCES Posts(PostID),
    FOREIGN KEY (TagID) REFERENCES Tags(TagID)
);

-- Съхранена Процедура
CREATE PROCEDURE GetPostsByUser
@UserID INT
AS
BEGIN
    SELECT * FROM Posts WHERE AuthorID = @UserID;
END;
GO

-- Функция
CREATE FUNCTION CountPostsByUser(@UserID INT)
RETURNS INT
AS
BEGIN
    DECLARE @PostCount INT;
    SELECT @PostCount = COUNT(*) FROM Posts WHERE AuthorID = @UserID;
    RETURN @PostCount;
END;
GO

CREATE TRIGGER UpdateCommentCount
ON Comments
AFTER INSERT
AS
BEGIN
    UPDATE Posts
    SET CommentCount = CommentCount + 1
    WHERE PostID IN (SELECT PostID FROM inserted);
END;
GO

INSERT INTO Users (Username, Email, Password, Role, RegistrationDate)
VALUES ('user1', 'user1@example.com', 'hashed_password1', 'User', GETDATE()),
       ('user2', 'user2@example.com', 'hashed_password2', 'User', GETDATE()),
       ('admin', 'admin@example.com', 'hashed_password3', 'Admin', GETDATE()),
       ('editor', 'editor@example.com', 'hashed_password4', 'Editor', GETDATE()),
       ('guest', 'guest@example.com', 'hashed_password5', 'Guest', GETDATE());

INSERT INTO Categories (CategoryName, Description)
VALUES ('Technology', 'Category for tech news'),
       ('Travel', 'Category for travel articles'),
       ('Health', 'Category for health tips and articles'),
       ('Education', 'Category for educational resources'),
       ('Sports', 'Category for sports news and analysis');

INSERT INTO Tags (TagName)
VALUES ('Tech'),
       ('Travel'),
       ('Health'),
       ('Education'),
       ('Sports');

INSERT INTO Posts (Title, Content, PublishDate, AuthorID, Status)
VALUES ('First Post', 'This is the first post', GETDATE(), 1, 'Published'),
       ('Second Post', 'This is the second post', GETDATE(), 2, 'Draft'),
       ('Third Post', 'This is the third post', GETDATE(), 3, 'Published'),
       ('Fourth Post', 'This is the fourth post', GETDATE(), 4, 'Published'),
       ('Fifth Post', 'This is the fifth post', GETDATE(), 2, 'Draft');

INSERT INTO Media (FileName, FileType, UploadDate, UploadedBy)
VALUES ('image1.jpg', 'image/jpeg', GETDATE(), 1),
       ('video1.mp4', 'video/mp4', GETDATE(), 2),
       ('document1.pdf', 'application/pdf', GETDATE(), 3),
       ('audio1.mp3', 'audio/mpeg', GETDATE(), 4),
       ('presentation.pptx', 'application/vnd.ms-powerpoint', GETDATE(), 1);

INSERT INTO Comments (Content, CommentDate, PostID, UserID)
VALUES ('Great article!', GETDATE(), 3, 2),
       ('Very informative.', GETDATE(), 3, 1),
       ('Interesting post.', GETDATE(), 4, 3),
       ('Thanks for sharing!', GETDATE(), 5, 4),
       ('Looking forward to more articles.', GETDATE(), 6, 2);

INSERT INTO PostCategories (PostID, CategoryID)
VALUES (3, 1),
       (4, 2),
       (5, 3),
       (6, 4),
       (7, 5);

INSERT INTO PostTags (PostID, TagID)
VALUES (3, 1),
       (4, 2),
       (5, 3),
       (6, 4),
       (7, 5);


/*DELETE FROM Users;
DELETE FROM Posts;
DELETE FROM Media;
DELETE FROM Comments;
DELETE FROM Tags;
DELETE FROM Categories;
DELETE FROM PostCategories;
DELETE FROM PostTags;

DELETE FROM PostTags;
DBCC CHECKIDENT ('PostTags', RESEED, 0);

DELETE FROM PostCategories;
DBCC CHECKIDENT ('PostCategories', RESEED, 0);

DELETE FROM Comments;
DBCC CHECKIDENT ('Comments', RESEED, 0);

DELETE FROM Media;
DBCC CHECKIDENT ('Media', RESEED, 0);

DELETE FROM Posts;
DBCC CHECKIDENT ('Posts', RESEED, 0);

DELETE FROM Users;
DBCC CHECKIDENT ('Users', RESEED, 0);

DELETE FROM Categories;
DBCC CHECKIDENT ('Categories', RESEED, 0);

DELETE FROM Tags;
DBCC CHECKIDENT ('Tags', RESEED, 0); */